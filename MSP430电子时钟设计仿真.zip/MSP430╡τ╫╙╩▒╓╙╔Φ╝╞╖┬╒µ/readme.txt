仿真软件： Proteus 8.9
MSP430开发环境：CCS12.2.0
注意：运行仿真时需要双击MCU，加载正确路径的hex文件： Code->MSP430F249->Debug->MSP430F249.hex
